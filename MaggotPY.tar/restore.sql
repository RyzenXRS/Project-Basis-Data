--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.4
-- Dumped by pg_dump version 17.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "basis data";
--
-- Name: basis data; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "basis data" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en-US';


ALTER DATABASE "basis data" OWNER TO postgres;

\encoding SQL_ASCII
\connect -reuse-previous=on "dbname='basis data'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: role_user; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.role_user AS ENUM (
    'admin',
    'pembudidaya',
    'supplier'
);


ALTER TYPE public.role_user OWNER TO postgres;

--
-- Name: status_stok; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.status_stok AS ENUM (
    'tersedia',
    'habis'
);


ALTER TYPE public.status_stok OWNER TO postgres;

--
-- Name: status_transaksi; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.status_transaksi AS ENUM (
    'diproses',
    'dikirim',
    'diterima',
    'dibatalkan'
);


ALTER TYPE public.status_transaksi OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: detail_transaksi_maggot; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.detail_transaksi_maggot (
    id_detail_transaksi_maggot character varying(10) NOT NULL,
    id_maggot character varying(10) NOT NULL,
    id_transaksi_maggot character varying(10) NOT NULL
);


ALTER TABLE public.detail_transaksi_maggot OWNER TO postgres;

--
-- Name: detail_transaksi_sampah; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.detail_transaksi_sampah (
    id_detail_transaksi_sampah character varying(10) NOT NULL,
    id_sampah_organik character varying(10) NOT NULL,
    id_transaksi_sampah character varying(10) NOT NULL
);


ALTER TABLE public.detail_transaksi_sampah OWNER TO postgres;

--
-- Name: maggot; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.maggot (
    id_maggot character varying(10) NOT NULL,
    jenis_maggot character varying(30) NOT NULL,
    harga_per_kg numeric(5,3) DEFAULT 0 NOT NULL,
    id_pembudidaya character varying(10) NOT NULL,
    CONSTRAINT harga_per_kg CHECK ((harga_per_kg >= (0)::numeric)),
    CONSTRAINT harga_per_kg_m CHECK ((harga_per_kg >= (0)::numeric))
);


ALTER TABLE public.maggot OWNER TO postgres;

--
-- Name: sampah_organik; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sampah_organik (
    id_sampah_organik character varying(10) NOT NULL,
    jenis_sampah character varying(30) NOT NULL,
    harga_per_kg numeric(5,3) DEFAULT 0 NOT NULL,
    id_supplier character varying(10) NOT NULL,
    CONSTRAINT harga_per_kg CHECK ((harga_per_kg >= (0)::numeric)),
    CONSTRAINT harga_per_kg_so CHECK ((harga_per_kg >= (0)::numeric))
);


ALTER TABLE public.sampah_organik OWNER TO postgres;

--
-- Name: stok_maggot; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stok_maggot (
    id_stok_maggot character varying(10) NOT NULL,
    id_maggot character varying(10) NOT NULL,
    jumlah_kg integer DEFAULT 0 NOT NULL,
    tanggal_update timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    status public.status_stok NOT NULL,
    CONSTRAINT jumlah_kg CHECK ((jumlah_kg >= 0)),
    CONSTRAINT jumlah_kg_sm CHECK ((jumlah_kg >= 0))
);


ALTER TABLE public.stok_maggot OWNER TO postgres;

--
-- Name: stok_sampah_organik; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stok_sampah_organik (
    id_stok_sampah character varying(10) NOT NULL,
    id_sampah_organik character varying(10) NOT NULL,
    jumlah_kg integer DEFAULT 0 NOT NULL,
    tanggal_update timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    status public.status_stok NOT NULL,
    CONSTRAINT jumlah_kg CHECK ((jumlah_kg >= 0)),
    CONSTRAINT jumlah_kg_sso CHECK ((jumlah_kg >= 0))
);


ALTER TABLE public.stok_sampah_organik OWNER TO postgres;

--
-- Name: transaksi_maggot; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.transaksi_maggot (
    id_transaksi_maggot character varying(10) NOT NULL,
    tanggal timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    id_pembeli character varying(10) NOT NULL,
    id_maggot character varying(10) NOT NULL,
    jumlah_kg integer DEFAULT 0 NOT NULL,
    deskripsi text,
    status public.status_transaksi DEFAULT 'diproses'::public.status_transaksi NOT NULL,
    CONSTRAINT jumlah_kg CHECK ((jumlah_kg >= 0)),
    CONSTRAINT jumlah_kg_tm CHECK ((jumlah_kg >= 0))
);


ALTER TABLE public.transaksi_maggot OWNER TO postgres;

--
-- Name: transaksi_sampah_organik; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.transaksi_sampah_organik (
    id_transaksi_sampah character varying(10) NOT NULL,
    tanggal timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    id_pembeli character varying(10) NOT NULL,
    id_sampah_organik character varying(10) NOT NULL,
    jumlah_kg integer DEFAULT 0 NOT NULL,
    deskripsi text,
    status public.status_transaksi DEFAULT 'diproses'::public.status_transaksi NOT NULL,
    CONSTRAINT jumlah_kg CHECK ((jumlah_kg >= 0)),
    CONSTRAINT jumlah_kg_tso CHECK ((jumlah_kg >= 0))
);


ALTER TABLE public.transaksi_sampah_organik OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id_user character varying(10) NOT NULL,
    nama_user character varying(20) NOT NULL,
    email character varying(50) NOT NULL,
    no_telp character varying(15) NOT NULL,
    password character varying(20) NOT NULL,
    alamat text NOT NULL,
    role public.role_user NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Data for Name: detail_transaksi_maggot; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.detail_transaksi_maggot (id_detail_transaksi_maggot, id_maggot, id_transaksi_maggot) FROM stdin;
\.
COPY public.detail_transaksi_maggot (id_detail_transaksi_maggot, id_maggot, id_transaksi_maggot) FROM '$$PATH$$/4988.dat';

--
-- Data for Name: detail_transaksi_sampah; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.detail_transaksi_sampah (id_detail_transaksi_sampah, id_sampah_organik, id_transaksi_sampah) FROM stdin;
\.
COPY public.detail_transaksi_sampah (id_detail_transaksi_sampah, id_sampah_organik, id_transaksi_sampah) FROM '$$PATH$$/4989.dat';

--
-- Data for Name: maggot; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.maggot (id_maggot, jenis_maggot, harga_per_kg, id_pembudidaya) FROM stdin;
\.
COPY public.maggot (id_maggot, jenis_maggot, harga_per_kg, id_pembudidaya) FROM '$$PATH$$/4984.dat';

--
-- Data for Name: sampah_organik; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sampah_organik (id_sampah_organik, jenis_sampah, harga_per_kg, id_supplier) FROM stdin;
\.
COPY public.sampah_organik (id_sampah_organik, jenis_sampah, harga_per_kg, id_supplier) FROM '$$PATH$$/4985.dat';

--
-- Data for Name: stok_maggot; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stok_maggot (id_stok_maggot, id_maggot, jumlah_kg, tanggal_update, status) FROM stdin;
\.
COPY public.stok_maggot (id_stok_maggot, id_maggot, jumlah_kg, tanggal_update, status) FROM '$$PATH$$/4990.dat';

--
-- Data for Name: stok_sampah_organik; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stok_sampah_organik (id_stok_sampah, id_sampah_organik, jumlah_kg, tanggal_update, status) FROM stdin;
\.
COPY public.stok_sampah_organik (id_stok_sampah, id_sampah_organik, jumlah_kg, tanggal_update, status) FROM '$$PATH$$/4991.dat';

--
-- Data for Name: transaksi_maggot; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.transaksi_maggot (id_transaksi_maggot, tanggal, id_pembeli, id_maggot, jumlah_kg, deskripsi, status) FROM stdin;
\.
COPY public.transaksi_maggot (id_transaksi_maggot, tanggal, id_pembeli, id_maggot, jumlah_kg, deskripsi, status) FROM '$$PATH$$/4986.dat';

--
-- Data for Name: transaksi_sampah_organik; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.transaksi_sampah_organik (id_transaksi_sampah, tanggal, id_pembeli, id_sampah_organik, jumlah_kg, deskripsi, status) FROM stdin;
\.
COPY public.transaksi_sampah_organik (id_transaksi_sampah, tanggal, id_pembeli, id_sampah_organik, jumlah_kg, deskripsi, status) FROM '$$PATH$$/4987.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id_user, nama_user, email, no_telp, password, alamat, role) FROM stdin;
\.
COPY public.users (id_user, nama_user, email, no_telp, password, alamat, role) FROM '$$PATH$$/4983.dat';

--
-- Name: detail_transaksi_maggot detail_transaksi_maggot_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detail_transaksi_maggot
    ADD CONSTRAINT detail_transaksi_maggot_pkey PRIMARY KEY (id_detail_transaksi_maggot);


--
-- Name: detail_transaksi_sampah detail_transaksi_sampah_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detail_transaksi_sampah
    ADD CONSTRAINT detail_transaksi_sampah_pkey PRIMARY KEY (id_detail_transaksi_sampah);


--
-- Name: maggot maggot_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.maggot
    ADD CONSTRAINT maggot_pkey PRIMARY KEY (id_maggot);


--
-- Name: sampah_organik sampah_organik_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sampah_organik
    ADD CONSTRAINT sampah_organik_pkey PRIMARY KEY (id_sampah_organik);


--
-- Name: stok_maggot stok_maggot_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stok_maggot
    ADD CONSTRAINT stok_maggot_pkey PRIMARY KEY (id_stok_maggot);


--
-- Name: stok_sampah_organik stok_sampah_organik_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stok_sampah_organik
    ADD CONSTRAINT stok_sampah_organik_pkey PRIMARY KEY (id_stok_sampah);


--
-- Name: transaksi_maggot transaksi_maggot_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transaksi_maggot
    ADD CONSTRAINT transaksi_maggot_pkey PRIMARY KEY (id_transaksi_maggot);


--
-- Name: transaksi_sampah_organik transaksi_sampah_organik_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transaksi_sampah_organik
    ADD CONSTRAINT transaksi_sampah_organik_pkey PRIMARY KEY (id_transaksi_sampah);


--
-- Name: users unique_email; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT unique_email UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id_user);


--
-- Name: detail_transaksi_maggot detail_transaksi_maggot_id_maggot_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detail_transaksi_maggot
    ADD CONSTRAINT detail_transaksi_maggot_id_maggot_fkey FOREIGN KEY (id_maggot) REFERENCES public.maggot(id_maggot);


--
-- Name: detail_transaksi_maggot detail_transaksi_maggot_id_transaksi_maggot_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detail_transaksi_maggot
    ADD CONSTRAINT detail_transaksi_maggot_id_transaksi_maggot_fkey FOREIGN KEY (id_transaksi_maggot) REFERENCES public.transaksi_maggot(id_transaksi_maggot);


--
-- Name: detail_transaksi_sampah detail_transaksi_sampah_id_sampah_organik_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detail_transaksi_sampah
    ADD CONSTRAINT detail_transaksi_sampah_id_sampah_organik_fkey FOREIGN KEY (id_sampah_organik) REFERENCES public.sampah_organik(id_sampah_organik);


--
-- Name: detail_transaksi_sampah detail_transaksi_sampah_id_transaksi_sampah_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detail_transaksi_sampah
    ADD CONSTRAINT detail_transaksi_sampah_id_transaksi_sampah_fkey FOREIGN KEY (id_transaksi_sampah) REFERENCES public.transaksi_sampah_organik(id_transaksi_sampah);


--
-- Name: maggot maggot_id_pembudidaya_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.maggot
    ADD CONSTRAINT maggot_id_pembudidaya_fkey FOREIGN KEY (id_pembudidaya) REFERENCES public.users(id_user);


--
-- Name: sampah_organik sampah_organik_id_supplier_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sampah_organik
    ADD CONSTRAINT sampah_organik_id_supplier_fkey FOREIGN KEY (id_supplier) REFERENCES public.users(id_user);


--
-- Name: stok_maggot stok_maggot_id_maggot_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stok_maggot
    ADD CONSTRAINT stok_maggot_id_maggot_fkey FOREIGN KEY (id_maggot) REFERENCES public.maggot(id_maggot);


--
-- Name: stok_sampah_organik stok_sampah_organik_id_sampah_organik_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stok_sampah_organik
    ADD CONSTRAINT stok_sampah_organik_id_sampah_organik_fkey FOREIGN KEY (id_sampah_organik) REFERENCES public.sampah_organik(id_sampah_organik);


--
-- Name: transaksi_maggot transaksi_maggot_id_maggot_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transaksi_maggot
    ADD CONSTRAINT transaksi_maggot_id_maggot_fkey FOREIGN KEY (id_maggot) REFERENCES public.maggot(id_maggot);


--
-- Name: transaksi_maggot transaksi_maggot_id_pembeli_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transaksi_maggot
    ADD CONSTRAINT transaksi_maggot_id_pembeli_fkey FOREIGN KEY (id_pembeli) REFERENCES public.users(id_user);


--
-- Name: transaksi_sampah_organik transaksi_sampah_organik_id_pembeli_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transaksi_sampah_organik
    ADD CONSTRAINT transaksi_sampah_organik_id_pembeli_fkey FOREIGN KEY (id_pembeli) REFERENCES public.users(id_user);


--
-- Name: transaksi_sampah_organik transaksi_sampah_organik_id_sampah_organik_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transaksi_sampah_organik
    ADD CONSTRAINT transaksi_sampah_organik_id_sampah_organik_fkey FOREIGN KEY (id_sampah_organik) REFERENCES public.sampah_organik(id_sampah_organik);


--
-- PostgreSQL database dump complete
--

